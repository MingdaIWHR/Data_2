import pandas as pd
import numpy as np
import os
import time

# Set the working directory
os.chdir('directory here')


# physical constraints
# enter for each reservoir
'''
# physical constraints
CR = 0.4  # Control ratio
Qthres = 20  # Threshold inflow value (cms) for starting pre-release operation 
Qdownmax = 184.1 # Allowed downstream maximum discharge
Smax = 298.643697 # maximum storage 
Smin = 115.534566 # minimum storage

# reservoir storage-stage relationship
a = 0.482746956#!!!!
b = -238.1707261#!!!!
c = 29431.52516#!!!!

# range of design flood
Qmax = 1400
Qmin = 200
Qinc = 75


# Load the inflow data from the Excel file
#inflow_data = pd.read_excel("design inflow.xlsx")

# Load the DUH data from the provided Excel file
duh_data = pd.read_excel("DUH.xlsx")
'''


# pre-release simulation
def calculate_reservoir_operation(forecast_data, Si, Smin, Smax, Qthres, RR, Qdownmax, Tpeak):
    # Initialize DataFrame
    operation_df = forecast_data.copy()
    operation_df['Qout_pre'] = 0.0
    operation_df['S'] = Si  # Start with the initial storage

    for index in range(len(operation_df)):
        row = operation_df.iloc[index]
        Qout_proposed = row['Qforecast'] * RR if row['Qforecast'] > Qthres else 0
        Qtotal_proposed = Qout_proposed + row['Qunc']

        # Apply non-decrease constraint
        if index > 0:
            Qout_non_decrease = max(Qout_proposed, operation_df.iloc[index-1]['Qout_pre'])
        else:
            Qout_non_decrease = Qout_proposed

        # Apply Qdownmax constraint
        Qout_downmax = min(Qout_non_decrease, Qdownmax - row['Qunc'])

        # Ensure non-negative Qout
        Qout_final = max(Qout_downmax, 0)

        # Apply time constraint for Qout after Tpeak
        if row['T'] >= Tpeak:
            Qout_final = 0

        # Calculate proposed storage
        delta_S = (row['Qin'] - Qout_final) * 3600 / 1e6  # Convert to MCM
        S_proposed = operation_df.iloc[index-1]['S'] + delta_S if index > 0 else Si + delta_S

        # Apply storage constraints to adjust Qout if necessary
        if S_proposed >= Smax:
            Qout_final = row['Qin']
        elif S_proposed <= Smin:
            Qout_final = 0

        # Recalculate storage with the final Qout
        delta_S = (row['Qin'] - Qout_final) * 3600 / 1e6
        S_final = min(max(Si + delta_S, Smin), Smax)

        # Update DataFrame
        operation_df.at[index, 'Qout_pre'] = Qout_final
        operation_df.at[index, 'S'] = S_final if index == 0 else operation_df.iloc[index-1]['S'] + delta_S

    return operation_df

# regular release simulation
def calculate_regular_reservoir_release(forecast_data, Si, Smin, Smax, Qthres, Qdownmax):
    # Initialize DataFrame
    operation_df = forecast_data.copy()
    operation_df['Qout_reg'] = 0.0  # Initialize regular Qout column
    operation_df['S'] = Si  # Start with the initial storage

    for index in range(len(operation_df)):
        row = operation_df.iloc[index]
        # Regular release logic based on Qin
        if row['Qin'] >= Qthres:
            Qout_reg = Qdownmax - row['Qunc']
        else:
            Qout_reg = 0

        # Ensure non-negative Qout
        Qout_reg = max(Qout_reg, 0)

        # Calculate storage adjustment based on regular Qout
        delta_S = (row['Qin'] - Qout_reg) * 3600 / 1e6  # Convert to MCM
        S_next = operation_df.iloc[index-1]['S'] + delta_S if index > 0 else Si + delta_S

        # Apply storage constraints
        if S_next >= Smax:
            Qout_reg = row['Qin']  # Prevent overflow
        elif S_next <= Smin:
            Qout_reg = 0  # Prevent underflow

        # Recalculate storage with the adjusted Qout
        delta_S = (row['Qin'] - Qout_reg) * 3600 / 1e6
        S_final = min(max(Si + delta_S, Smin), Smax)

        # Update DataFrame
        operation_df.at[index, 'Qout_reg'] = Qout_reg
        operation_df.at[index, 'S'] = S_final if index == 0 else operation_df.iloc[index-1]['S'] + delta_S

    return operation_df

# check reservoir failures
def calculate_storage_indicator(operation_df, Smin, Smax, outflow_col):

    # Ensure 'Indicator' column exists and initialize with zeros
    operation_df['Indicator'] = 0

    for index, row in operation_df.iterrows():
        S_current = row['S']
        Qin_next = row['Qin'] * 3600 / 1e6  # Convert next Qin to MCM
        # Use the specified outflow column for Qout_current calculation
        Qout_current = row[outflow_col] * 3600 / 1e6  # Convert current Qout to MCM

        possible_max_S = S_current + Qin_next
        possible_min_S = S_current - Qout_current

        # Determine the indicator based on possible max and min S
        if possible_max_S >= Smax:
            indicator = 1
        elif possible_min_S <= Smin:
            indicator = -1
        else:
            indicator = 0

        operation_df.at[index, 'Indicator'] = indicator

    return operation_df

# add no operation release (post-reelase) simulation
def calculate_no_release(forecast_data, Si, Smin, Smax):

    operation_df = forecast_data.copy()
    operation_df['Qspill'] = 0.0  # Initialize spillage Qout column
    operation_df['S'] = Si  # Start with the initial storage

    for index in range(len(operation_df)):
        row = operation_df.iloc[index]
        S_previous = Si if index == 0 else operation_df.at[index-1, 'S']

        # Calculate storage adjustment based solely on Qin, as Qspill remains 0 until overflow
        delta_S = row['Qin'] * 3600 / 1e6  # Convert Qin to MCM
        S_next = S_previous + delta_S

        # Prevent overflow by calculating necessary spillage to maintain Smax
        if S_next > Smax:
            Qspill = (S_next - Smax) * (1e6 / 3600)  # Convert excess storage to cms for spillage
            S_next = Smax  # Adjust storage back to Smax
        else:
            Qspill = 0

        # Update DataFrame with spillage and adjusted storage
        operation_df.at[index, 'Qspill'] = Qspill
        operation_df.at[index, 'S'] = S_next

    return operation_df

# print failure status
def check_reservoir_status(operation_df_with_indicator):

    # Check for the presence of specific indicators
    has_fc_fail = 1 in operation_df_with_indicator['Indicator'].values
    has_ws_fail = -1 in operation_df_with_indicator['Indicator'].values

    if has_fc_fail and has_ws_fail:
        print("Both fail")
    elif has_fc_fail:
        print("FC fail")
    elif has_ws_fail:
        print("WS fail")
    else:
        print("Normal OP")

# to calculate teh water level from the SSR
def calculate_water_level(S):
    # Calculate the discriminant
    discriminant = b**2 - 4*a*(c - S)
    # Calculate the positive root of the quadratic equation
    y = (-b + np.sqrt(discriminant)) / (2*a)
    return y


# binary search
def failure_condition(operation_results_with_indicator):
    # Check for the presence of failure indicators
    has_fc_fail = 1 in operation_results_with_indicator['Indicator'].values
    has_ws_fail = -1 in operation_results_with_indicator['Indicator'].values
    
    # Define failure as the occurrence of either FC fail or WS fail
    failure_occurred = has_fc_fail or has_ws_fail
    return failure_occurred

# pre-release Si_min
def binary_search_min_Si_fail(low, high, increment, constraints, forecast_data):
    while low <= high:
        mid = (low + high) // 2
        # Use pre-defined simulation function
        simulation_result = calculate_reservoir_operation(
            forecast_data, mid, constraints['Smin'], constraints['Smax'], 
            constraints['Qthres'], constraints['RR'], constraints['Qdownmax'], constraints['Tpeak']
        )
        # Use pre-defined indicator function
        operation_results_with_indicator = calculate_storage_indicator(simulation_result, constraints['Smin'], constraints['Smax'], 'Qout_pre')
        
        # Check for failure using the results
        failure_occurred = failure_condition(operation_results_with_indicator)
        
        if failure_occurred:
            high = mid - increment
        else:
            low = mid + increment

    # The loop exits when 'low' exceeds 'high'. The minimum failing 'Si' is around this threshold.
    # Final adjustment may be needed based on your specific criteria for determining failure.
    final_check_Si = low if low < Smax else Smax  # Ensure final_check_Si does not exceed the upper limit.
    final_simulation = calculate_reservoir_operation(
        forecast_data, final_check_Si, constraints['Smin'], constraints['Smax'], 
        constraints['Qthres'], constraints['RR'], constraints['Qdownmax'], constraints['Tpeak']
    )
    final_results_with_indicator = calculate_storage_indicator(final_simulation, constraints['Smin'], constraints['Smax'], 'Qout_pre')

    # Determine if the final adjusted 'Si' leads to failure and adjust the return value accordingly.
    return final_check_Si if failure_condition(final_results_with_indicator) else final_check_Si - increment

# regular release Si min
def binary_search_min_Si_fail_reg_release(low, high, increment, constraints, forecast_data):

    while low <= high:
        mid = (low + high) // 2
        # Adjusted to call regular release simulation function
        simulation_result = calculate_regular_reservoir_release(
            forecast_data, mid, constraints['Smin'], constraints['Smax'], 
            constraints['Qthres'], constraints['Qdownmax']
        )
        # The rest remains the same
        operation_results_with_indicator = calculate_storage_indicator(simulation_result, constraints['Smin'], constraints['Smax'], 'Qout_reg')
        
        if failure_condition(operation_results_with_indicator):
            high = mid - increment
        else:
            low = mid + increment

    final_check_Si = low if low < Smax else Smax  # Ensure final_check_Si does not exceed the upper limit.
    final_simulation = calculate_regular_reservoir_release(
        forecast_data, final_check_Si, constraints['Smin'], constraints['Smax'], 
        constraints['Qthres'], constraints['Qdownmax']
    )
    final_results_with_indicator = calculate_storage_indicator(final_simulation, constraints['Smin'], constraints['Smax'], 'Qout_reg')

    return final_check_Si if failure_condition(final_results_with_indicator) else final_check_Si - increment


# no op Si (for post reelase)
def binary_search_min_Si_fail_noop(low, high, increment, constraints, forecast_data):
    while low <= high:
        mid = (low + high) // 2
        simulation_result = calculate_no_release(
            forecast_data, mid, constraints['Smin'], constraints['Smax']
        )
        operation_results_with_indicator = calculate_storage_indicator(simulation_result, constraints['Smin'], constraints['Smax'], 'Qspill')
        
        failure_occurred = any(operation_results_with_indicator['Qspill'] > 0)
        
        if failure_occurred:
            high = mid - increment
        else:
            low = mid + increment

    final_check_Si = low if low < Smax else Smax
    final_simulation = calculate_no_release(
        forecast_data, final_check_Si, constraints['Smin'], constraints['Smax']
    )
    final_results_with_indicator = calculate_storage_indicator(final_simulation, constraints['Smin'], constraints['Smax'], 'Qspill')

    return final_check_Si if any(final_results_with_indicator['Qspill'] > 0) else final_check_Si - increment

# Record the start time
start_time = time.time()

# Assuming duh_data is already loaded as shown earlier
# Initialize an empty DataFrame to store the results
results_df = pd.DataFrame(columns=['Qpeak', 'Tld', 'RR', 'min_si_pre', 'min_si_reg'])

for Qpeak in range(Qmin, Qmax+1, Qinc):
    # Note: calculate_forecast_inflow_data function call is replaced with direct calculation within the loop
    # Adjust the column name for unit hydrograph values based on your actual DUH data structure
    inflow_data = pd.DataFrame({
        'T': duh_data['T'],  # Assuming duh_data is predefined
        'Qin': duh_data['DUH'] * Qpeak
    })

    # Initialize and populate the shifted inflow data DataFrame
    shifted_inflow_data = pd.DataFrame({
        'T': range(0, 501),  # Time from 0 to 500 hours
        'Qin': 0  # Initialize inflow values with zeros
    })

    # Populate the shifted inflow data based on the original inflow data
    for index, row in inflow_data.iterrows():
        if row['T'] + 100 < 501:  # Ensure we do not exceed 500 hours
            shifted_inflow_data.at[row['T'] + 100, 'Qin'] = row['Qin']

    # Find Tpeak in the shifted inflow data
    peak_value = shifted_inflow_data['Qin'].max()
    Tpeak = shifted_inflow_data[shifted_inflow_data['Qin'] == peak_value].iloc[0]['T']

    for Tld in [6, 24, 72]:
        # Create and populate the forecasted inflow data based on the lead time
        forecast_inflow_data = shifted_inflow_data.copy()
        forecast_inflow_data['Qforecast'] = forecast_inflow_data['Qin'].shift(-Tld, fill_value=0)
        forecast_inflow_data['Qunc'] = (forecast_inflow_data['Qin'] * (1 - CR)) / CR
        
        for RR in np.arange(0.1, 1.1, 0.1):
            # Update constraints for each combination, including RR
            constraints = {
                "Smin": Smin, 
                "Smax": Smax, 
                "Qthres": Qthres, 
                "Qdownmax": Qdownmax, 
                "Tpeak": Tpeak,
                "RR": RR
            }
            
            # Calculate min_si_pre
            min_si_pre = binary_search_min_Si_fail(Smin, Smax, 1, constraints, forecast_inflow_data)
            
            # Calculate min_si_reg
            min_si_reg = binary_search_min_Si_fail_reg_release(Smin, Smax, 1, constraints, forecast_inflow_data)
            
            # Calculate min_si_noop
            min_si_noop = binary_search_min_Si_fail_noop(Smin, Smax, 1, constraints, forecast_inflow_data)           
            
            
            # Creating a new DataFrame for the current row to be appended
            new_row_df = pd.DataFrame({
                'Qpeak': [Qpeak], 
                'Tld': [Tld], 
                'RR': [RR], 
                'min_si_pre': [min_si_pre], 
                'min_si_reg': [min_si_reg],
                'min_si_noop': [min_si_noop]                
            })

            # Using pandas.concat to add the new row
            results_df = pd.concat([results_df, new_row_df], ignore_index=True)


# Calculate water levels outside of the loop to save computational resources
results_df['WL_pre'] = results_df['min_si_pre'].apply(calculate_water_level)
results_df['WL_reg'] = results_df['min_si_reg'].apply(calculate_water_level)
results_df['WL_noop'] = results_df['min_si_noop'].apply(calculate_water_level)


# Save results_df to an Excel file
results_df.to_excel('results.xlsx', index=False, engine='openpyxl')

print('all data saved')

# Record the end time
final_end_time = time.time()

# Calculate the total execution time
execution_time = final_end_time - start_time

print(f"Total execution time: {execution_time} seconds")


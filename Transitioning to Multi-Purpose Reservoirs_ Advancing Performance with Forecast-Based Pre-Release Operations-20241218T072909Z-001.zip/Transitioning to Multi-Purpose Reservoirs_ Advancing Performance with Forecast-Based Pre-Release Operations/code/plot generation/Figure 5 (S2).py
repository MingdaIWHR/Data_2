import pandas as pd
import plotly.graph_objects as go
import os


# Set the working directory
os.chdir('directory here')


# Load the data
# result from "static performance measure: pre-release vs regular release"
df = pd.read_excel('results.xlsx')

# Step 2: Calculate delta_WL_pre and delta_WL_reg
df['delta_pre'] = df['WL_pre'] - df['WL_noop']
df['delta_reg'] = df['WL_reg'] - df['WL_noop']

# Filter the data based on given conditions
conditions = (
    ((df['Tld'] == 72) & (df['RR'] >= 0.1) & (df['RR'] <= 0.4)) |
    ((df['Tld'] == 24) & (df['RR'] >= 0.3) & (df['RR'] <= 0.7)) |
    ((df['Tld'] == 6) & (df['RR'] >= 0.6) & (df['RR'] <= 1))
)
df_filtered = df[conditions]

# Ensure 'Tld' is treated as categorical for the colorscale mapping
df_filtered['Tld'] = pd.Categorical(df_filtered['Tld'])
df_filtered['Tld_code'] = df_filtered['Tld'].cat.codes

# Define custom colorscale based on 'Tld' values mapping
# Adjust the colorscale to accurately map your 'Tld' values to the desired colors
colorscale = [[0, 'green'], [0.5, 'blue'], [1, 'red']]


# Specify the columns to plot, in the desired order
dimensions = [
    dict(range=[df_filtered['Qpeak'].min(), df_filtered['Qpeak'].max()], label='', values=df_filtered['Qpeak']),
    dict(range=[df_filtered['delta_reg'].min(), df_filtered['delta_reg'].max()], label='', values=df_filtered['delta_reg']),
    dict(range=[df_filtered['RR'].min(), df_filtered['RR'].max()], label='', values=df_filtered['RR']),
    dict(range=[df_filtered['delta_pre'].min(), df_filtered['delta_pre'].max()], label='', values=df_filtered['delta_pre']),
]


# Create the figure
fig = go.Figure(data=go.Parcoords( 
    line=dict(color=df_filtered['Tld_code'], colorscale=colorscale, showscale=False),  # Use filtered Tld_code for coloring
    dimensions=dimensions
))

# Update layout with global font size settings
fig.update_layout(
    font=dict(size=24, family='Times New Roman, bold')  # Adjust the global font size if needed
)


# Add 'max' annotation on the left side with bold Times New Roman text
fig.add_annotation(
    x=1.04, y=1,  # Position near the top left
    text="MAX",  # The text content
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# Add 'min' annotation on the left side with bold Times New Roman text
fig.add_annotation(
    x=1.035, y=0,  # Position near the bottom left
    text="MIN",  # The text content
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# Add red line for 72-hr
fig.add_shape(
    type="line",
    x0=0.785, y0=1.03, x1=0.815, y1=1.03,
    line=dict(color='red', width=3),
    xref="paper", yref="paper"
)
fig.add_annotation(
    x=0.85, y=1.05,
    text="72-hr",
    showarrow=False,
    font=dict(size=24, color='red', family="Times New Roman, bold"),
    xref="paper", yref="paper"
)

# Add blue line for 24-hr
fig.add_shape(
    type="line",
    x0=0.785, y0=0.98, x1=0.815, y1=0.98,
    line=dict(color='blue', width=3),
    xref="paper", yref="paper"
)
fig.add_annotation(
    x=0.85, y=1,
    text="24-hr",
    showarrow=False,
    font=dict(size=24, color='blue', family="Times New Roman, bold"),
    xref="paper", yref="paper"
)

# Add green line for 6-hr
fig.add_shape(
    type="line",
    x0=0.785, y0=0.93, x1=0.815, y1=0.93,
    line=dict(color='green', width=3),
    xref="paper", yref="paper"
)
fig.add_annotation(
    x=0.85, y=0.95,
    text="6-hr",
    showarrow=False,
    font=dict(size=24, color='green', family="Times New Roman, bold"),
    xref="paper", yref="paper"
)




# add "Peak Discharge"
fig.add_annotation(
    x=-0.03, y=-0.11,  # Adjust position to align with the Peak Discharge axis
    text="     Peak<br>Discharge (cms)",  # Text content with line break
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# add "FLWL Delta reg"
fig.add_annotation(
    x=0.35, y=-0.11,  # Adjust position to align with the Peak Discharge axis
    text="  FLWL Change<br>Regular Release (m)",  # Text content with line break
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# add "Release Ratio"
fig.add_annotation(
    x=0.69, y=-0.11,  # Adjust position to align with the Peak Discharge axis
    text="Release<br>  Ratio",  # Text content with line break
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# add "FLWL Delta Pre-Release"
fig.add_annotation(
    x=1.04, y=-0.11,  # Adjust position to align with the Peak Discharge axis
    text="FLWL Change<br>Pre-Release (m)",  # Text content with line break
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

import plotly.offline as pyo

# Save the figure to an HTML file
pyo.plot(fig, filename='Barren River Lake Fig 5 new.html')
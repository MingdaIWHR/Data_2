
import pandas as pd
import plotly.graph_objects as go
import os

# Set the working directory
os.chdir('directory here')


# Load the data
# result from "static performance measure: pre-release vs current operation
df = pd.read_excel('results3.xlsx')


# Ensure 'Tld' is treated as categorical for the colorscale mapping
df['Tld'] = pd.Categorical(df['Tld'])
df['Tld_code'] = df['Tld'].cat.codes

# Define custom colorscale based on 'Tld' values mapping
# Adjust the colorscale to accurately map your 'Tld' values to the desired colors
colorscale = [[0, 'green'], [0.5, 'blue'], [1, 'red']]  # You might need to adjust this based on the actual Tld values

# Specify the columns to plot, in the desired order, without labels
dimensions = [
    dict(range=[df['Qpeak'].min(), df['Qpeak'].max()], label='', values=df['Qpeak']),
    dict(range=[df['Zi'].min(), df['Zi'].max()], label='', values=df['Zi']),
    dict(range=[df['Water_Level_Change'].min(), df['Water_Level_Change'].max()], label='', values=df['Water_Level_Change']),
    dict(range=[df['WL_Reduction'].min(), df['WL_Reduction'].max()], label='', values=df['WL_Reduction']),
    dict(range=[df['WL_Fluctuation'].min(), df['WL_Fluctuation'].max()], label='', values=df['WL_Fluctuation']),
]

# Create the figure
fig = go.Figure(data=go.Parcoords(
    line=dict(color=df['Tld_code'], colorscale=colorscale, showscale=False),
    dimensions=dimensions
))

# Update layout with global font size settings
fig.update_layout(
    font=dict(size=22, family='Times New Roman, bold')
)

# add needed notations
# Add 'max' annotation on the left side with bold Times New Roman text
fig.add_annotation(
    x=1.04, y=1,  # Position near the top left
    text="MAX",  # The text content
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# Add 'min' annotation on the left side with bold Times New Roman text
fig.add_annotation(
    x=1.035, y=0,  # Position near the bottom left
    text="MIN",  # The text content
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# Add annotation for 'Peak Discharge (cms)'
fig.add_annotation(
    x=-0.03, y=-0.11,  # Adjust position to align with the Peak Discharge axis
    text="     Peak<br>Discharge (cms)",  # Text content with line break
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# Add annotation for 'Initial Water Level (m)'
fig.add_annotation(
    x=0.22, y=-0.11,  # Adjust position to align with the Initial Water Level axis
    text="Initial Water<br>  Level (m)",  # Text content with line break
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# Add annotation for 'Change in Water Level (m)'
fig.add_annotation(
    x=0.5, y=-0.11,  # Adjust position to align with the Change in Water Level axis
    text="End Flood Water<br>Level Change (m)",  # Text content with line break
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# Add annotation for 'Water Level Reduction'
fig.add_annotation(
    x=0.8, y=-0.11,  # Adjust position to align with the Water Level Reduction axis
    text="End Flood Water<br>Level Reduction",  # Text content with line break
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# Add annotation for 'Water Level Fluctuation'
fig.add_annotation(
    x=1.04, y=-0.11,  # Adjust position to align with the Water Level Fluctuation axis
    text="End Flood Water<br>Level Fluctuation",  # Text content with line break
    showarrow=False,  # No arrow
    font=dict(size=24, color="black", family="Times New Roman, bold"),  # Font size, color, and style
    xref="paper", yref="paper", align="left"
)

# Add red line for 72-hr
fig.add_shape(
    type="line",
    x0=0.635, y0=1.03, x1=0.665, y1=1.03,
    line=dict(color='red', width=3),
    xref="paper", yref="paper"
)
fig.add_annotation(
    x=0.7, y=1.05,
    text="72-hr",
    showarrow=False,
    font=dict(size=24, color='red', family="Times New Roman, bold"),
    xref="paper", yref="paper"
)

# Add blue line for 24-hr
fig.add_shape(
    type="line",
    x0=0.635, y0=0.98, x1=0.665, y1=0.98,
    line=dict(color='blue', width=3),
    xref="paper", yref="paper"
)
fig.add_annotation(
    x=0.7, y=1,
    text="24-hr",
    showarrow=False,
    font=dict(size=24, color='blue', family="Times New Roman, bold"),
    xref="paper", yref="paper"
)

# Add green line for 6-hr
fig.add_shape(
    type="line",
    x0=0.635, y0=0.93, x1=0.665, y1=0.93,
    line=dict(color='green', width=3),
    xref="paper", yref="paper"
)
fig.add_annotation(
    x=0.7, y=0.95,
    text="6-hr",
    showarrow=False,
    font=dict(size=24, color='green', family="Times New Roman, bold"),
    xref="paper", yref="paper"
)



import plotly.offline as pyo

# Save the figure to an HTML file
pyo.plot(fig, filename='Barren River Lake Fig 4 new.html')
